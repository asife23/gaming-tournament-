import React, { useState, useEffect } from "react";
import { Match, UserWallet, Transaction, LeaderboardUser, GameCategory } from "./types";
import { TRANSLATIONS, SEED_MATCHES, SEED_LEADERBOARD } from "./data";
import MatchesView from "./components/MatchesView";
import WalletView from "./components/WalletView";
import LeaderboardView from "./components/LeaderboardView";
import AdminPanelView from "./components/AdminPanelView";
import { 
  Trophy, 
  Gamepad, 
  Wallet, 
  Award, 
  Settings, 
  Languages, 
  RotateCcw,
  Sparkles,
  Smartphone,
  User,
  Heart,
  Lock,
  CheckCircle,
  HelpCircle,
  LogIn,
  LogOut,
  UserCheck,
  Shield,
  Mail,
  Key,
  Check,
  UserPlus
} from "lucide-react";
import { auth } from "./firebase";
import { 
  signInAnonymously, 
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut
} from "firebase/auth";
import {
  seedDatabaseIfEmpty,
  upsertUserProfile,
  checkIsAdmin,
  registerAdmin,
  addCategory,
  deleteCategory,
  createMatch,
  updateMatchSlots,
  addTransaction,
  updateTransactionStatus,
  declareMatchResults,
  subscribeMatches,
  subscribeCategories,
  subscribeLeaderboard,
  subscribeUserProfile,
  subscribeTransactions
} from "./services/db";

export default function App() {
  const [lang, setLang] = useState<"bn" | "en">("bn");
  const [activeTab, setActiveTab] = useState<"lobby" | "myMatches" | "wallet" | "leaderboard" | "admin">("lobby");
  
  // Custom Player profile info
  const [userIgn, setUserIgn] = useState<string>("Boss_Rifat");
  const [userUid, setUserUid] = useState<string>("529384820");
  const [ignInput, setIgnInput] = useState<string>("Boss_Rifat");

  // Secret visual toggle for Admin Mode (to safely upload to Play Store without showing "Admin Tab" to standard users)
  const [logoClickCount, setLogoClickCount] = useState<number>(0);
  const [secretAdminVisible, setSecretAdminVisible] = useState<boolean>(() => {
    return localStorage.getItem("pz_secret_admin_unlocked") === "true";
  });

  const handleLogoClick = () => {
    const nextCount = logoClickCount + 1;
    setLogoClickCount(nextCount);
    if (nextCount >= 5) {
      const isCurrentlyVisible = secretAdminVisible;
      setSecretAdminVisible(!isCurrentlyVisible);
      localStorage.setItem("pz_secret_admin_unlocked", (!isCurrentlyVisible).toString());
      setLogoClickCount(0);
      alert(
        lang === "bn" 
          ? (!isCurrentlyVisible ? "🔓 গোপন এডমিন অপশন চালু হয়েছে! নিচে নেভিগেশন বারে 'Admin/সেটিংস' দেখতে পাবেন।" : "🔒 গোপন এডমিন অপশন বন্ধ করা হয়েছে!") 
          : (!isCurrentlyVisible ? "🔓 Secret Admin mode enabled! You will now see 'Settings/Admin' tab below." : "🔒 Secret Admin mode disabled!")
      );
    }
  };

  // Authentication & admin checks
  const [fbUser, setFbUser] = useState<any>(null);
  const [isAdminUser, setIsAdminUser] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [adminPasscodeVerified, setAdminPasscodeVerified] = useState<boolean>(() => {
    return localStorage.getItem("pz_admin_authed") === "true";
  });
  const [adminPinInput, setAdminPinInput] = useState<string>("");
  const [adminPinError, setAdminPinError] = useState<string>("");

  // Email authentication modal states
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<"login" | "signup" | "admin_login">("login");
  const [authEmail, setAuthEmail] = useState<string>("");
  const [authPassword, setAuthPassword] = useState<string>("");
  const [authGamerTag, setAuthGamerTag] = useState<string>("");
  const [authAdminPin, setAuthAdminPin] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
  const [authSuccess, setAuthSuccess] = useState<string>("");

  // Sign in with Email / Password
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");
    try {
      if (!authEmail.trim() || !authPassword.trim()) {
        throw new Error(lang === "bn" ? "দয়া করে ইমেইল এবং পাসওয়ার্ড দুটিই পূরণ করুন।" : "Please fill in both email and password.");
      }
      const userCredential = await signInWithEmailAndPassword(auth, authEmail.trim(), authPassword.trim());
      const user = userCredential.user;
      
      // Also register as admin if we are in admin login mode
      if (authMode === "admin_login") {
        const isCurrentlyAdmin = await checkIsAdmin(user.uid);
        if (isCurrentlyAdmin) {
          setIsAdminUser(true);
          setAdminPasscodeVerified(true);
          localStorage.setItem("pz_admin_authed", "true");
        } else {
          // If not currently registered admin, check if pin is correct to register them
          if (authAdminPin === "7890") {
            await registerAdmin(user.uid);
            setIsAdminUser(true);
            setAdminPasscodeVerified(true);
            localStorage.setItem("pz_admin_authed", "true");
          } else {
            throw new Error(lang === "bn" ? "আপনি এখন এডমিন নন! এডমিন হতে সঠিক সিকিউরিটি পিন (৭৮৯০) দিন।" : "You are not registered as an Admin! Enter the correct Admin PIN of 7890 to register.");
          }
        }
      }

      setAuthSuccess(lang === "bn" ? "লগইন সফল হয়েছে!" : "Successfully logged in!");
      setTimeout(() => {
        setShowAuthModal(false);
        setAuthError("");
        setAuthSuccess("");
      }, 1200);
    } catch (err: any) {
      console.error("Firebase auth login error:", err);
      const errCode = err?.code || "";
      const errMsg = err?.message || String(err);
      
      if (errCode.includes("unauthorized-domain") || errMsg.includes("unauthorized-domain")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ হোস্টিং ডোমেইন অনুমোদিত নয় (Unauthorized Domain)! আপনি নেটলিফাই (Netlify), ভিআরসেল (Vercel) বা গিটহাবে হোস্ট করলে Firebase Console-এ গিয়ে Authentication -> Settings -> Authorized Domains ট্যাবে আপনার ক্লাউড ডোমেন বা ওয়েবসাইট লিংকটি যুক্ত করে দিন।"
            : "⚠️ Unauthorized Host Domain! Please go to Firebase Console -> Authentication -> Settings -> Authorized Domains tab, and add your deployed URL (e.g., playtowin.netlify.app) to allow logins."
        );
      } else if (errCode.includes("operation-not-allowed") || errMsg.includes("operation-not-allowed")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ ইমেল/পাসওয়ার্ড অথেন্টিকেশন প্রোভাইডার নিষ্ক্রিয় করা আছে! দয়া করে Firebase Console-এ গিয়ে Authentication -> Sign-in method ট্যাবে গিয়ে Email/Password প্রোভাইডারটি Enable বা চালু করে দিন।"
            : "⚠️ Email/Password Auth is disabled in Firebase! Please go to Firebase Console -> Authentication -> Sign-in method, click Email/Password and Enable it."
        );
      } else if (errCode.includes("user-not-found") || errMsg.includes("user-not-found")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ এই ইমেইলের কোনো একাউন্ট পাওয়া যায়নি! দয়া করে ‘নতুন অ্যাকাউন্ট’ (Sign Up) তৈরি করুন।"
            : "⚠️ Account not found! Please register a new account via the Sign Up tab first."
        );
      } else if (errCode.includes("wrong-password") || errMsg.includes("wrong-password") || errCode.includes("invalid-credential") || errMsg.includes("invalid-credential")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ ভুল পাসওয়ার্ড বা ইমেইল! দয়া করে আপনার পাসওয়ার্ড ও ইমেইল চেক করে আবার চেষ্টা করুন।"
            : "⚠️ Wrong password, email or invalid credentials! Please check your credentials and try again."
        );
      } else if (errCode.includes("too-many-requests") || errMsg.includes("too-many-requests")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ অনেক বেশি বার চেষ্টা করা হয়েছে! নিরাপত্তা জনিত কারণে একাউন্ট আপাতত ব্লক করা আছে, কিছুক্ষণ পর পুনরায় চেষ্টা করুন।"
            : "⚠️ Too many login requests! Access to this account has been temporarily disabled due to many attempts. Try again later."
        );
      } else {
        setAuthError(errMsg);
      }
    }
  };

  // Register New User Profile with Email & Password
  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");
    try {
      const gTag = authGamerTag.trim();
      if (!gTag) {
        throw new Error(lang === "bn" ? "দয়া করে গেম ইন-নেম (IGN) দিন।" : "Please specify an In-Game Name (IGN).");
      }
      if (!authEmail.trim() || !authPassword.trim()) {
        throw new Error(lang === "bn" ? "দয়া করে ইমেইল এবং পাসওয়ার্ড দুটিই দিন।" : "Both email and password are required.");
      }
      if (authPassword.length < 6) {
        throw new Error(lang === "bn" ? "পাসওয়ার্ড অবশ্যই কমপক্ষে ৬ অক্ষরের হতে হবে।" : "Password must be at least 6 characters.");
      }

      // Create primary user credentials in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(auth, authEmail.trim(), authPassword.trim());
      const user = userCredential.user;

      // Bootstrap their user profile inside users collections
      await upsertUserProfile(user.uid, {
        gamertag: gTag,
        balance: 120, // Starting gift coins
        deposit: 80,
        winning: 40
      });

      // If registered as admin with PIN
      if (authMode === "admin_login" && authAdminPin === "7890") {
        await registerAdmin(user.uid);
        setIsAdminUser(true);
        setAdminPasscodeVerified(true);
        localStorage.setItem("pz_admin_authed", "true");
      }

      setAuthSuccess(lang === "bn" ? "সাফল্যের সাথে অ্যাকাউন্ট তৈরি হয়েছে!" : "Account registered successfully!");
      // Cache values
      localStorage.setItem("pz_cached_tag", gTag);
      setUserIgn(gTag);
      setIgnInput(gTag);

      setTimeout(() => {
        setShowAuthModal(false);
        setAuthError("");
        setAuthSuccess("");
      }, 1250);
    } catch (err: any) {
      console.error("Firebase auth signup error:", err);
      const errCode = err?.code || "";
      const errMsg = err?.message || String(err);
      
      if (errCode.includes("unauthorized-domain") || errMsg.includes("unauthorized-domain")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ হোস্টিং ডোমেইন অনুমোদিত নয় (Unauthorized Domain)! আপনি নেটলিফাই (Netlify), ভিআরসেল (Vercel) বা গিটহাবে হোস্ট করলে Firebase Console-এ গিয়ে Authentication -> Settings -> Authorized Domains ট্যাবে আপনার ওয়েবসাইট ডোমেনটি যুক্ত করে দিন।"
            : "⚠️ Unauthorized Host Domain! Please go to Firebase Console -> Authentication -> Settings -> Authorized Domains tab, and add your deployed URL (e.g., playtowin.netlify.app) to allow registrations."
        );
      } else if (errCode.includes("operation-not-allowed") || errMsg.includes("operation-not-allowed")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ ইমেল/পাসওয়ার্ড অথেন্টিকেশন প্রোভাইডার নিষ্ক্রিয় করা আছে! দয়া করে Firebase Console-এ গিয়ে Authentication -> Sign-in method ট্যাবে গিয়ে Email/Password প্রোভাইডারটি Enable বা চালু করে দিন।"
            : "⚠️ Email/Password Auth is disabled in Firebase! Please go to Firebase Console -> Authentication -> Sign-in method, click Email/Password and Enable it."
        );
      } else if (errCode.includes("email-already-in-use") || errMsg.includes("email-already-in-use")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ এই ইমেইলটি ইতিমধ্যে আরেকটি অ্যাকাউন্টে ব্যবহৃত হচ্ছে! অন্য ইমেইল ব্যবহার করুন অথবা লগইন ট্যাব সিলেক্ট করে লগইন করুন।"
            : "⚠️ This email is already in use! Please choose another email, or proceed to the Login tab."
        );
      } else if (errCode.includes("weak-password") || errMsg.includes("weak-password")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ পাসওয়ার্ডটি দুর্বল! পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।"
            : "⚠️ Password is too weak! It must be at least 6 characters long."
        );
      } else if (errCode.includes("invalid-email") || errMsg.includes("invalid-email")) {
        setAuthError(
          lang === "bn"
            ? "⚠️ ইমেইল এড্রেসটির ফরম্যাট সঠিক নয়।"
            : "⚠️ The email address format is invalid."
        );
      } else {
        setAuthError(errMsg);
      }
    }
  };

  // Sign out user profile
  const handleUserLogout = async () => {
    if (confirm(lang === "bn" ? "আপনি কি লগআউট করতে চান?" : "Are you sure you want to sign out from your account?")) {
      try {
        await signOut(auth);
        localStorage.removeItem("pz_admin_authed");
        setAdminPasscodeVerified(false);
        setIsAdminUser(false);
        setFbUser(null);
        // Force page reload to safely reload local states to fallback/guest
        window.location.reload();
      } catch (err) {
        console.error("Logout request failed: ", err);
      }
    }
  };

  // Live state declarations (init empty, hydrated in real-time by Firebase subscriptions)
  const [matches, setMatches] = useState<Match[]>([]);
  const [wallet, setWallet] = useState<UserWallet>({
    balance: 0,
    deposit: 0,
    winning: 0,
    transactions: []
  });
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([]);
  const [categories, setCategories] = useState<GameCategory[]>([
    { id: "ff", name: "Free Fire", localName: "ফ্রি ফায়ার ও সিএস", icon: "🔥" },
    { id: "pubg", name: "PUBG Mobile", localName: "পাবজি মোবাইল", icon: "🔫" },
    { id: "ludo", name: "Ludo King", localName: "লুডু কিং ক্লাসিক", icon: "🎲" },
    { id: "mlbb", name: "Mobile Legends", localName: "মোবাইল লেজেন্ডস", icon: "⚔️" },
    { id: "dls", name: "DLS", localName: "ডিএলএস সকার", icon: "⚽" }
  ]);

  // Establish connection and authenticate player
  useEffect(() => {
    let active = true;

    // Use a stable, persistent client-side UID so users' wallets/data always persist on their device even if auth is disabled.
    let localUid = localStorage.getItem("pz_local_uid");
    if (!localUid) {
      localUid = "usr_" + Math.random().toString(36).substring(2, 11) + "_" + Math.floor(1000 + Math.random() * 9000);
      localStorage.setItem("pz_local_uid", localUid);
    }

    const initFallbackUser = async (uid: string) => {
      if (!active) return;
      console.log("Using unauthenticated/anonymous fallback player ID:", uid);
      const mockUser = { uid, isFallback: true };
      setFbUser(mockUser);
      setUserUid(uid);

      const savedTag = localStorage.getItem("pz_cached_tag") || "Player_" + uid.replace(/\D/g, "").substring(0, 5);
      localStorage.setItem("pz_cached_tag", savedTag);
      setUserIgn(savedTag);
      setIgnInput(savedTag);

      try {
        await upsertUserProfile(uid, { gamertag: savedTag });
        await seedDatabaseIfEmpty();
        const matchedAdmin = await checkIsAdmin(uid);
        if (matchedAdmin) {
          setIsAdminUser(true);
        }
      } catch (e) {
        console.error("Local profile bootstrap status:", e);
      }
      setLoading(false);
    };

    signInAnonymously(auth)
      .catch((err) => {
        console.warn("Anonymous authentication failed (probably not enabled in Firebase Console): ", err);
        // Instant bootstrap fallback to ensure app is immediately online and ready for use!
        initFallbackUser(localUid);
      });

    const unsubscribeAuth = onAuthStateChanged(auth, async (current) => {
      if (current && active) {
        setFbUser(current);
        const uid = current.uid;
        setUserUid(uid);

        const savedTag = localStorage.getItem("pz_cached_tag") || "Player_" + uid.substring(0, 5);
        localStorage.setItem("pz_cached_tag", savedTag);
        setUserIgn(savedTag);
        setIgnInput(savedTag);

        try {
          await upsertUserProfile(uid, { gamertag: savedTag });
          await seedDatabaseIfEmpty();
          const matchedAdmin = await checkIsAdmin(uid);
          if (matchedAdmin) {
            setIsAdminUser(true);
          }
        } catch (e) {
          console.error("Auth profile bootstrap status:", e);
        }
        setLoading(false);
      }
    });

    return () => {
      active = false;
      unsubscribeAuth();
    };
  }, []);

  // Bind real-time Firestore listeners once authenticated
  useEffect(() => {
    if (!fbUser) return;

    // Connect matches
    const unsubMatches = subscribeMatches((updatedMatches) => {
      setMatches(updatedMatches);
    });

    // Connect game categories
    const unsubCats = subscribeCategories((updatedCats) => {
      if (updatedCats && updatedCats.length > 0) {
        setCategories(updatedCats);
      }
    });

    // Connect global leaderboard rankings
    const unsubLeads = subscribeLeaderboard((updatedLeads) => {
      setLeaderboard(updatedLeads);
    });

    // Connect current player's wallet and tag profile
    const unsubProfile = subscribeUserProfile(fbUser.uid, (userInfo) => {
      if (userInfo) {
        setUserIgn(userInfo.gamertag);
        setIgnInput(userInfo.gamertag);
        setWallet((prev) => ({
          ...prev,
          balance: userInfo.balance || 0,
          deposit: userInfo.deposit || 0,
          winning: userInfo.winning || 0
        }));
      }
    });

    // Connect general transaction receipts list
    const unsubTrxs = subscribeTransactions((updatedTransactions) => {
      setWallet((prev) => ({
        ...prev,
        transactions: updatedTransactions
      }));
    });

    return () => {
      unsubMatches();
      unsubCats();
      unsubLeads();
      unsubProfile();
      unsubTrxs();
    };
  }, [fbUser]);

  const t = TRANSLATIONS[lang];

  // Restores seeded dataset remotely securely
  const handleResetData = async () => {
    if (confirm(lang === "bn" ? "আপনি কি আগের সব টুর্নামেন্টের ডাটা রিসেট করতে চান?" : "Are you sure you want to reset all data back to original seeds?")) {
      await seedDatabaseIfEmpty();
    }
  };

  // Submit Gamer Tag profile adjustments to Firestore
  const handleSaveGamerTag = async (newTag: string) => {
    const freshTag = newTag.trim();
    if (!freshTag) return;
    setUserIgn(freshTag);
    localStorage.setItem("pz_cached_tag", freshTag);
    if (fbUser) {
      await upsertUserProfile(fbUser.uid, { gamertag: freshTag });
    }
  };

  // Join match - Books seat, deducts balance, and updates slots list
  const handleJoinMatch = async (matchId: string, slotNo: number, ign: string) => {
    const targetMatch = matches.find((m) => m.id === matchId);
    if (!targetMatch) return;

    const fee = targetMatch.entryFee;
    if (wallet.balance < fee) {
      alert(lang === "bn" 
        ? "আপনার পর্যাপ্ত ব্যালেন্স নেই! দয়া করে ওয়ালেট থেকে রিচার্জ করুন।" 
        : "Insufficient balance! Please recharge from your wallet.");
      return;
    }

    const updatedSlots = targetMatch.slots.map((sl) => {
      if (sl.slotNo === slotNo) {
        return { ...sl, isBooked: true, registeredBy: ign };
      }
      return sl;
    });

    try {
      if (fbUser) {
        // 1. Deduct fee and save to profile
        await upsertUserProfile(fbUser.uid, {
          gamertag: ign,
          balance: wallet.balance - fee
        });

        // 2. Add entry fee receipt transaction
        const trxId = `trx-join-${Date.now()}`;
        const newTrx: Transaction = {
          id: trxId,
          type: "Entry Fee",
          amount: fee,
          status: "Approved",
          date: new Date().toLocaleString("en-US", { hour: "numeric", minute: "numeric", hour12: true }),
          matchId: targetMatch.id
        };
        await addTransaction({ ...newTrx, userId: fbUser.uid, userIgn: ign });

        // 3. Register booking slots
        await updateMatchSlots(matchId, updatedSlots);
        setUserIgn(ign);
      }
    } catch (e) {
      console.error("Error booking slot:", e);
    }
  };

  // Add a pending deposit/withdraw request from WalletView
  const handleAddTransaction = async (trx: Transaction) => {
    if (!fbUser) return;
    try {
      await addTransaction({
        ...trx,
        userId: fbUser.uid,
        userIgn: userIgn
      });
    } catch (e) {
      console.error("Error requesting transaction:", e);
    }
  };

  // Approve Recharge Request from Admin Panel
  const handleApproveTransaction = async (id: string, approve: boolean) => {
    const targetTrx = wallet.transactions.find((trx) => trx.id === id);
    if (!targetTrx) return;
    try {
      const trxWithUser = targetTrx as any;
      const associatedUserId = trxWithUser.userId || fbUser?.uid;
      await updateTransactionStatus(id, approve, associatedUserId, targetTrx.amount, targetTrx.type);
    } catch (e) {
      console.error("Error approving transaction:", e);
    }
  };

  // Create match from Admin Panel
  const handleAddMatch = async (match: Match) => {
    try {
      await createMatch(match);
    } catch (e) {
      console.error("Error creating match:", e);
    }
  };

  const handleAddCategory = async (newCat: GameCategory) => {
    try {
      await addCategory(newCat);
    } catch (e) {
      console.error("Error adding category:", e);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    try {
      await deleteCategory(id);
    } catch (e) {
      console.error("Error deleting category:", e);
    }
  };

  // End match and declare results from Admin panel
  const handleDeclareResults = async (
    matchId: string,
    results: { rank: number; playerIgn: string; kills: number; prizeWon: number }[]
  ) => {
    try {
      await declareMatchResults(matchId, results);
    } catch (e) {
      console.error("Error declaring results:", e);
    }
  };

  // Filter matches where user has at least one booked slot
  const myMatches = matches.filter((m) =>
    m.slots?.some((sl) => sl.isBooked && sl.registeredBy?.toLowerCase() === userIgn.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 select-none">
        <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl flex flex-col items-center gap-4 text-center max-w-sm shadow-2xl animate-pulse">
          <div className="p-4 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/25 shadow-md shadow-indigo-950 inline-block mb-2">
            <Trophy className="w-10 h-10 text-yellow-400" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase font-mono tracking-widest text-slate-200">PLAY TO WIN</h2>
            <p className="text-[11px] text-slate-400 font-mono mt-1 leading-relaxed">
              {lang === "bn" ? "সার্ভার কানেকশন এবং ডাটাবেজ প্রিপেয়ার হচ্ছে..." : "Connecting to Firebase server and loading database..."}
            </p>
          </div>
          <div className="w-24 h-1 bg-slate-950 border border-slate-850 rounded-full overflow-hidden relative mt-2">
            <div className="absolute top-0 left-0 h-full w-12 bg-indigo-500 rounded-full animate-ping"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative select-none antialiased" id="app_frame_canvas">
      
      {/* PERSISTENT GUEST ALERT WARNING BANNER */}
      {(fbUser?.isFallback || !fbUser?.email) && (
        <div className="bg-indigo-950/85 border-b border-indigo-900/40 px-4 py-2.5 text-center text-[11px] text-indigo-200 transition-all flex flex-col md:flex-row items-center justify-center gap-3 shadow-lg select-none">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-indigo-500/10 border border-indigo-500/25 text-indigo-400 font-black font-mono text-[9px] uppercase rounded-md tracking-wider">
              {lang === "bn" ? "গেস্ট মুড সচল" : "Guest Mode Active"}
            </span>
            <p className="font-bold leading-tight font-sans">
              {lang === "bn" 
                ? "আপনার গেমের ব্যালেন্স এবং আর্নিং কয়েন আজীবনের জন্য সুরক্ষিত রাখতে এখনই এখানে ক্লিক করে ফ্রী একাউন্ট খুলুন!" 
                : "To secure your wallet balance and game statistics permanently, create a free account now!"}
            </p>
          </div>
          <button
            onClick={() => {
              setAuthMode("signup");
              setShowAuthModal(true);
            }}
            className="px-4 py-1.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-mono font-black text-[10px] rounded-lg shadow-md hover:shadow-indigo-500/10 transition-all cursor-pointer flex items-center gap-1.5 uppercase tracking-wider scale-95 hover:scale-100 shrink-0"
          >
            <LogIn className="w-3 h-3 text-yellow-300" />
            {lang === "bn" ? "অ্যাকাউন্ট খুলুন / লগইন" : "Register / Login"}
          </button>
        </div>
      )}

      {/* GLORIOUS ESPORTS NAVIGATION HEADER */}
      <header className="border-b border-slate-900 bg-slate-950/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo brand with secret trigger */}
          <div 
            onClick={handleLogoClick}
            className="flex items-center gap-3 self-start cursor-pointer select-none active:scale-95 transition-transform"
            title={lang === "bn" ? "টুর্নামেন্ট লোগো" : "Tournament Logo"}
          >
            <div className="p-2.5 bg-gradient-to-br from-indigo-500/20 to-cyan-500/10 text-indigo-400 rounded-xl border border-indigo-500/25 shadow-lg shadow-indigo-950/30">
              <Trophy className="w-6 h-6 text-yellow-400 animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-black bg-gradient-to-r from-yellow-400 via-indigo-400 to-emerald-400 bg-clip-text text-transparent uppercase tracking-wider flex items-center gap-1.5 font-mono">
                {t.appName}
              </h1>
              <p className="text-[10px] text-slate-400 font-mono font-medium">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Quick Active user Profile Widget & Controls */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 border-slate-900 pt-3 sm:pt-0">
            <div className="flex items-center gap-2.5 bg-slate-900 border border-slate-850 p-1.5 rounded-xl text-left">
              <div className="w-7 h-7 bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 rounded-lg flex items-center justify-center font-bold font-mono">
                {isAdminUser ? "👑" : "🎮"}
              </div>
              <div className="leading-tight">
                <input 
                  type="text" 
                  value={ignInput} 
                  onChange={(e) => setIgnInput(e.target.value)}
                  onBlur={() => handleSaveGamerTag(ignInput)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSaveGamerTag(ignInput);
                  }}
                  title="Modify Gamer Tag and Press Enter/Blur"
                  className="block text-[11px] font-extrabold text-white bg-transparent outline-none max-w-[95px] border-b border-transparent hover:border-slate-800 focus:border-indigo-500 font-mono cursor-pointer"
                />
                <span className="block text-[8px] text-slate-500 font-mono">
                  {fbUser?.email ? fbUser.email : `Guest ID: ${userUid.substring(0, 6)}`}
                </span>
              </div>
              
              <div className="bg-slate-950 border border-slate-800 px-2 py-1 rounded-lg text-right ml-1">
                <span className="text-[10px] text-yellow-400 font-black font-mono">🪙 {wallet.balance}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {fbUser?.email ? (
                <button
                  onClick={handleUserLogout}
                  className="p-2 rounded-xl border border-rose-950/40 bg-rose-950/20 text-rose-400 hover:text-white hover:bg-rose-600 transition cursor-pointer"
                  title={lang === "bn" ? "লগআউট করুন" : "Sign Out"}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => {
                    setAuthMode("login");
                    setShowAuthModal(true);
                  }}
                  className="p-2 rounded-xl border border-indigo-500/30 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-600 hover:text-white transition cursor-pointer font-bold shrink-0"
                  title={lang === "bn" ? "লগইন / রেজিষ্ট্রেশন করুন" : "Log In / Register"}
                >
                  <LogIn className="w-4 h-4 animate-bounce" />
                </button>
              )}

              <button
                onClick={() => setLang(lang === "bn" ? "en" : "bn")}
                className="p-2 rounded-xl border border-slate-850 bg-slate-900 text-slate-400 hover:text-indigo-400 transition cursor-pointer shrink-0"
                title={t.switchLanguage}
              >
                <Languages className="w-4 h-4" />
              </button>

              <button
                onClick={handleResetData}
                className="p-2 rounded-xl border border-slate-850 bg-slate-900 text-slate-500 hover:text-red-400 transition cursor-pointer shrink-0"
                title="Reset Database"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </header>

      {/* CORE NAVIGATION TABS */}
      <nav className="border-b border-slate-900 bg-slate-900/10 py-3">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth">
          {[
            { id: "lobby" as const, label: t.lobby, icon: Gamepad },
            { id: "myMatches" as const, label: `${t.myMatches} (${myMatches.length})`, icon: Award },
            { id: "wallet" as const, label: t.wallet, icon: Wallet },
            { id: "leaderboard" as const, label: t.leaderboard, icon: Trophy },
            { id: "admin" as const, label: t.adminMode, icon: Settings, condition: isAdminUser || adminPasscodeVerified || secretAdminVisible }
          ]
          .filter(tab => !("condition" in tab) || tab.condition)
          .map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black tracking-tight transition duration-250 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/15"
                    : "text-slate-400 hover:text-white hover:bg-slate-900/60"
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? "text-yellow-400" : "text-slate-500"}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </nav>

      {/* MAIN LAYOUT CANVAS */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        
        {activeTab === "lobby" && (
          <div className="animate-fadeIn">
            <MatchesView 
              matches={matches} 
              wallet={wallet} 
              onJoinMatch={handleJoinMatch} 
              lang={lang} 
              categories={categories}
            />
          </div>
        )}

        {activeTab === "myMatches" && (
          <div className="animate-fadeIn">
            <MatchesView 
              matches={myMatches} 
              wallet={wallet} 
              onJoinMatch={handleJoinMatch} 
              lang={lang} 
              categories={categories}
            />
          </div>
        )}

        {activeTab === "wallet" && (
          <div className="animate-fadeIn">
            <WalletView 
              wallet={wallet} 
              onAddTransaction={handleAddTransaction} 
              lang={lang} 
            />
          </div>
        )}

        {activeTab === "leaderboard" && (
          <div className="animate-fadeIn">
            <LeaderboardView 
              leaderboard={leaderboard} 
              lang={lang} 
            />
          </div>
        )}

        {activeTab === "admin" && !adminPasscodeVerified && !isAdminUser && (
          <div className="max-w-md mx-auto my-12 bg-slate-900 border border-slate-800 p-8 rounded-3xl text-center shadow-2xl animate-fadeIn">
            <div className="p-4 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20 shadow-md shadow-indigo-950 inline-block mb-4">
              <Lock className="w-8 h-8 text-indigo-400" />
            </div>
            <h2 className="text-lg font-black uppercase font-mono tracking-wider text-white">
              {lang === "bn" ? "🔐 এডমিন সিকিউরিটি গেটওয়ে" : "🔐 Admin Security Lock"}
            </h2>
            <p className="text-xs text-slate-400 mt-2 font-medium">
              {lang === "bn" 
                ? "ভুল অ্যাক্সেস ঠেকাতে সিকিউরিটি পিন দিন। ডিফল্ট পিন হচ্ছে 7890" 
                : "Please enter the administrative secure passcode. Default PIN is 7890"}
            </p>

            <div className="mt-6 flex flex-col gap-3">
              <input
                type="password"
                value={adminPinInput}
                onChange={(e) => {
                  setAdminPinInput(e.target.value);
                  setAdminPinError("");
                }}
                maxLength={8}
                placeholder="••••"
                className="w-full bg-slate-950 border border-slate-800 text-center tracking-widest text-lg font-bold text-white rounded-xl p-3 outline-none focus:border-indigo-500"
              />
              
              {adminPinError && (
                <p className="text-[11px] text-rose-400 font-bold font-mono">
                  ❌ {adminPinError}
                </p>
              )}

              <button
                onClick={async () => {
                  if (adminPinInput === "7890") {
                    setAdminPasscodeVerified(true);
                    localStorage.setItem("pz_admin_authed", "true");
                    if (fbUser) {
                      await registerAdmin(fbUser.uid);
                      setIsAdminUser(true);
                    }
                  } else {
                    setAdminPinError(lang === "bn" ? "ভুল সিকিউরিটি পিন! আবার চেষ্টা করুন।" : "Incorrect passcode PIN! Please try again.");
                  }
                }}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold font-mono text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                {lang === "bn" ? "ভেরিফাই করুন" : "Unlock Panel"}
              </button>
            </div>
            
            <div className="mt-8 pt-4 border-t border-slate-850 text-[10px] text-slate-500 text-left leading-relaxed flex items-start gap-2">
              <HelpCircle className="w-3.5 h-3.5 text-slate-600 shrink-0 mt-0.5" />
              <span>
                {lang === "bn"
                  ? "সঠিক পিন দিলে এই ডিভাইসটিকে ডাটাবেজে স্থায়ী এডমিন হিসাবে রেজিস্টার করা হবে। যাতে আপনি সরাসরি টুর্নামেন্ট ও ব্যালেন্স কন্ট্রোল করতে পারেন।"
                  : "Unlocking with the correct PIN will instantly register your active profile securely as a direct cloud administrator."}
              </span>
            </div>
          </div>
        )}

        {activeTab === "admin" && (adminPasscodeVerified || isAdminUser) && (
          <div className="animate-fadeIn">
            <AdminPanelView 
              matches={matches}
              transactions={wallet.transactions}
              onAddMatch={handleAddMatch}
              onApproveTransaction={handleApproveTransaction}
              onDeclareResults={handleDeclareResults}
              lang={lang}
              categories={categories}
              onAddCategory={handleAddCategory}
              onDeleteCategory={handleDeleteCategory}
            />
          </div>
        )}

      </main>

      {/* FOOTER BAR */}
      <footer className="border-t border-slate-900/80 bg-slate-950/40 py-6 text-slate-500 text-[11px] font-mono mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="flex items-center gap-1.5">
            © 2026 {t.appName} — Made in Bangladesh with <Heart className="w-3 h-3 text-red-500 fill-red-500" />
          </p>
          <div className="flex items-center gap-4 text-slate-600">
            <span>Framework: React 19 + Tailwind v4</span>
            <span>Platform: Cloud Sandboxed Container + Firestore</span>
          </div>
        </div>
      </footer>

      {/* GLORIOUS ESPORTS AUTHENTICATION MODAL */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 relative shadow-2xl animate-scaleUp">
            
            {/* Close modal button */}
            <button 
              onClick={() => {
                setShowAuthModal(false);
                setAuthError("");
                setAuthSuccess("");
              }}
              className="absolute top-4 right-4 text-slate-500 hover:text-white bg-slate-950/50 p-2 rounded-full border border-slate-850 hover:bg-slate-800 transition-colors cursor-pointer text-xs"
            >
              ✕
            </button>

            {/* Modal Logo branding */}
            <div className="text-center mb-6">
              <div className="inline-block p-3 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/25 mb-3 shadow-md shadow-slate-950">
                {authMode === "admin_login" ? (
                  <Shield className="w-8 h-8 text-yellow-400 animate-pulse" />
                ) : authMode === "signup" ? (
                  <UserPlus className="w-8 h-8 text-emerald-400" />
                ) : (
                  <LogIn className="w-8 h-8 text-indigo-400" />
                )}
              </div>
              <h2 className="text-xl font-black font-sans uppercase tracking-wide text-white">
                {authMode === "admin_login" 
                  ? (lang === "bn" ? "🔐 এডমিন সিকিউরিটি গেট" : "Admin Security Access")
                  : authMode === "signup"
                    ? (lang === "bn" ? "🎮 নতুন অ্যাকাউন্ট রেজিস্ট্রেশন" : "Create eSports Account")
                    : (lang === "bn" ? "🎮 একাউন্টে লগইন করুন" : "Sign In to Account")}
              </h2>
              <p className="text-xs text-slate-400 font-medium leading-relaxed font-sans mt-1">
                {authMode === "admin_login"
                  ? (lang === "bn" ? "ম্যাচ কন্ট্রোল ও পে-আউট এর জন্য সাইন-ইন করুন" : "Log in to publish matches & distribute prizes")
                  : authMode === "signup"
                    ? (lang === "bn" ? "নতুন অ্যাকাউন্টে ১২০ ফ্রি গেম কয়েন গিফট পাবেন!" : "Get 120 free signup bonus coins immediately!")
                    : (lang === "bn" ? "টুর্নামেন্ট জয়েন করতে আপনার একাউন্ট পোর্টালে ঢুকুন" : "Welcome back, player! Enter credentials below")}
              </p>
            </div>

            {/* Mode selection tabs */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-xl border border-slate-850/80 mb-5">
              <button 
                type="button"
                onClick={() => {
                  setAuthMode("login");
                  setAuthError("");
                }}
                className={`py-1.5 rounded-lg text-[10px] font-black uppercase font-sans tracking-wide transition-colors cursor-pointer ${
                  authMode === "login" 
                    ? "bg-indigo-600 text-white shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {lang === "bn" ? "লগইন" : "Log In"}
              </button>
              <button 
                type="button"
                onClick={() => {
                  setAuthMode("signup");
                  setAuthError("");
                }}
                className={`py-1.5 rounded-lg text-[10px] font-black uppercase font-sans tracking-wide transition-colors cursor-pointer ${
                  authMode === "signup" 
                    ? "bg-indigo-600 text-white shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {lang === "bn" ? "হিসাব খুলুন" : "Sign Up"}
              </button>
              <button 
                type="button"
                onClick={() => {
                  setAuthMode("admin_login");
                  setAuthError("");
                }}
                className={`py-1.5 rounded-lg text-[10px] font-black uppercase font-sans tracking-wide transition-colors cursor-pointer ${
                  authMode === "admin_login" 
                    ? "bg-amber-600 text-slate-950 shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {lang === "bn" ? "এডমিন" : "Admin"}
              </button>
            </div>

            {/* Error and Success states banner */}
            {authError && (
              <div className="p-3 bg-red-950/20 border border-red-900/60 text-red-300 rounded-xl mb-4 text-[11px] font-bold font-mono text-left leading-relaxed flex items-start gap-2">
                <span className="shrink-0 mt-0.5">⚠️</span>
                <div>{authError}</div>
              </div>
            )}
            {authSuccess && (
              <div className="p-3 bg-emerald-950/20 border border-emerald-900/60 text-emerald-300 rounded-xl mb-4 text-[11px] font-bold font-mono text-left leading-relaxed flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>{authSuccess}</div>
              </div>
            )}

            {/* Credential input form layout */}
            <form onSubmit={authMode === "signup" ? handleEmailSignUp : handleEmailLogin} className="space-y-4">
              
              {/* GAMERTAG FIELD - Only on signup */}
              {authMode === "signup" && (
                <div>
                  <label className="block text-[10px] uppercase font-bold font-mono text-slate-400 mb-1.5">
                    {lang === "bn" ? "গেম ইন-গেম নেম (IGN)" : "Gaming Name (IGN)"}
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-500">🎮</span>
                    <input 
                      type="text"
                      required
                      placeholder="e.g. Boss_Rifat"
                      value={authGamerTag}
                      onChange={(e) => setAuthGamerTag(e.target.value)}
                      className="w-full bg-slate-950 hover:bg-slate-950 text-white border border-slate-800 focus:border-indigo-500 rounded-xl py-2 pl-9 pr-4 text-xs font-mono font-bold outline-none"
                    />
                  </div>
                </div>
              )}

              {/* EMAIL FIELD */}
              <div>
                <label className="block text-[10px] uppercase font-bold font-mono text-slate-400 mb-1.5">
                  {lang === "bn" ? "ইমেইল এড্রেস" : "Email Address"}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="email"
                    required
                    placeholder="player@example.com"
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    className="w-full bg-slate-950 hover:bg-slate-950 text-white border border-slate-800 focus:border-indigo-500 rounded-xl py-2 pl-9 pr-4 text-xs font-mono outline-none"
                  />
                </div>
              </div>

              {/* PASSWORD FIELD */}
              <div>
                <label className="block text-[10px] uppercase font-bold font-mono text-slate-400 mb-1.5">
                  {lang === "bn" ? "পাসওয়ার্ড (৬+ অক্ষর)" : "Security Password (6+ char)"}
                </label>
                <div className="relative">
                  <Key className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="password"
                    required
                    placeholder="••••••••"
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    className="w-full bg-slate-950 hover:bg-slate-950 text-white border border-slate-800 focus:border-indigo-500 rounded-xl py-2 pl-9 pr-4 text-xs font-mono outline-none"
                  />
                </div>
              </div>

              {/* ADMIN PASSCODE GATE - Only visible on Admin selection */}
              {authMode === "admin_login" && (
                <div className="p-3 bg-amber-950/20 border border-amber-900/40 rounded-xl">
                  <label className="block text-[10px] uppercase font-black font-mono text-amber-400 mb-1.5">
                    {lang === "bn" ? "এডমিন সিকিউরিটি পিন (৭৮৯০)" : "Admin Core Security PIN (7890)"}
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-amber-500" />
                    <input 
                      type="password"
                      placeholder="e.g. 7890"
                      value={authAdminPin}
                      onChange={(e) => setAuthAdminPin(e.target.value)}
                      className="w-full bg-slate-950 text-amber-200 border border-amber-900/50 focus:border-amber-500 rounded-xl py-2 pl-9 pr-4 text-xs font-mono outline-none font-black tracking-widest text-center"
                    />
                  </div>
                  <p className="text-[9px] text-amber-500 mt-1.5 font-sans leading-tight">
                    {lang === "bn"
                      ? "🔐 অ্যাকাউন্ট রেজিস্ট্রেশন এর সময় সঠিক পিন দিলে এই একাউন্টকে মেঘের ডাটাবেজে পার্মানেন্ট এডমিন ক্ষমতা দেওয়া হবে।"
                      : "Unlocking with correct PIN will declare this log in authenticated directly with administrator privileges in our cloud database."}
                  </p>
                </div>
              )}

              {/* SUBMIT BUTTON */}
              <button 
                type="submit"
                className={`w-full py-2.5 rounded-xl font-mono text-xs uppercase font-black tracking-wider transition-all cursor-pointer shadow-lg ${
                  authMode === "admin_login"
                    ? "bg-amber-600 hover:bg-amber-500 text-slate-950 hover:shadow-amber-600/10"
                    : authMode === "signup"
                      ? "bg-emerald-600 hover:bg-emerald-500 text-white hover:shadow-emerald-600/10"
                      : "bg-indigo-600 hover:bg-indigo-500 text-white hover:shadow-indigo-600/10"
                }`}
              >
                {authMode === "admin_login"
                  ? (lang === "bn" ? "এডমিন ভেরিফাই ও সাইন ইন" : "Verify Admin & Sign In")
                  : authMode === "signup"
                    ? (lang === "bn" ? "১২০ কয়েন বোনাস সহ একাউন্ট তৈরি করুন" : "Claim Premium Account and 120 Bonus Coins")
                    : (lang === "bn" ? "নিরাপদ সাইন ইন" : "Secure Authentication")}
              </button>

            </form>

            <div className="mt-4 text-center">
              {authMode === "signup" ? (
                <button
                  type="button"
                  onClick={() => setAuthMode("login")}
                  className="text-[10px] text-slate-500 hover:text-indigo-400 font-mono transition-all underline bg-transparent border-0 cursor-pointer"
                >
                  {lang === "bn" ? "আগের অ্যাকাউন্ট আছে? লগইন করুন" : "Already have an account? Log In"}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setAuthMode("signup")}
                  className="text-[10px] text-slate-500 hover:text-emerald-400 font-mono transition-all underline bg-transparent border-0 cursor-pointer"
                >
                  {lang === "bn" ? "নতুন অ্যাকাউন্ট খুলতে চান? রেজিষ্ট্রেশন করুন" : "Need a professional eSports profile? Sign Up Now"}
                </button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
